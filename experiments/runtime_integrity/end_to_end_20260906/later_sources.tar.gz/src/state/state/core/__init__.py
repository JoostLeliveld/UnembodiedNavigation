"""Core state estimation utilities."""
