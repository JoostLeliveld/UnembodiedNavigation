"""Core perception utilities."""
