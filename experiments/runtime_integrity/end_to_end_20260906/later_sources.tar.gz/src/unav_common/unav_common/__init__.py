"""Shared utilities for UnembodiedNavigation."""
